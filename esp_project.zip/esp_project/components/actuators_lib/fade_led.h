#ifndef FADE_LED_H_
#define FADE_LED_H_

#include <inttypes.h>
#include <esp_err.h>

esp_err_t init_fade_led();

#endif