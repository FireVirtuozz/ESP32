#ifndef BUZZER_H_
#define BUZZER_H_

#include "ledLib.h"

//KY006 : Passive buzzer, sound according to PWM's frequency

//passive buzzer
#define BUZZER_GPIO 19
#define BUZZER_RESOLUTION LEDC_TIMER_13_BIT
#define BUZZER_START_FREQ 2000
#define BUZZER_MIN_DUTY 0
#define BUZZER_MAX_DUTY (GET_MAX_DUTY(BUZZER_RESOLUTION) / 2)
#define BUZZER_SPEED_MODE LEDC_LOW_SPEED_MODE
#define BUZZER_LEDC_TIMER LEDC_TIMER_2
#define BUZZER_LEDC_CHANNEL LEDC_CHANNEL_4

// 2. Détermination pour le KY006 (1 canal si activé, 0 sinon)
#if CONFIG_USE_KY006
    #define KY006_CHANNELS 1
#else
    #define KY006_CHANNELS 0
#endif

#endif