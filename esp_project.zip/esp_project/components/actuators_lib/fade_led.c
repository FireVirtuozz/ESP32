#define LEDC_TEST_FADE_TIME    (3000)

//semaphore for fade events
static SemaphoreHandle_t counting_sem = NULL;

/*
 * This callback function will be called when fade operation has ended
 * Use callback only if you are aware it is being called inside an ISR
 * Otherwise, you can use a semaphore to unblock tasks
 */
static IRAM_ATTR bool cb_ledc_fade_end_event(const ledc_cb_param_t *param, void *user_arg)
{
    BaseType_t taskAwoken = pdFALSE;

#if CONFIG_DEBUG_LEDC
    print_callback_param(*param);
#endif

    //if fade end event
    if (param->event == LEDC_FADE_END_EVT) {
        //getting the semaphore from parameter
        SemaphoreHandle_t counting_sem_local = (SemaphoreHandle_t) user_arg;
        //from ISR because it is an IRAM function (hardware)
        xSemaphoreGiveFromISR(counting_sem_local, &taskAwoken);
    }

    return (taskAwoken == pdTRUE);
}

esp_err_t init_fade_led(ledc_channel_config_t *ledc_channel, uint8_t size) {
    // Initialize fade service.
    err = ledc_fade_func_install(0);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) installing fade", esp_err_to_name(err));
        return;
    }
    ledc_cbs_t callbacks = {
        .fade_cb = cb_ledc_fade_end_event
    };
    counting_sem = xSemaphoreCreateCounting(size, 0);
    if (counting_sem == NULL) {
        log_msg(TAG, "Error creating ledc semaphore");
        return;
    }

    for (ch = 0; ch < size; ch++) {
        err = ledc_cb_register(ledc_channel[ch].speed_mode, ledc_channel[ch].channel, &callbacks, (void *) counting_sem);
        if (err != ESP_OK) {
            log_msg(TAG, "Error (%s) registering callback on channel %d", esp_err_to_name(err), ch);
            return;
        }
    }
}


/**
 * Apply fade duty
 * -Set & start fade, and then the ISR callback will be called
 */
void ledc_duty_fade(const uint32_t duty, const uint8_t idx) {

    esp_err_t err;

    if (idx > LEDC_CHANNELS_COUNT) {
        log_msg(TAG, "Out of bounds");
        return;
    }

    err = ledc_set_fade_with_time(ledc_channel[idx].speed_mode,
                                ledc_channel[idx].channel, duty, LEDC_TEST_FADE_TIME);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) setting fade duty %d on channel %d",
            esp_err_to_name(err), duty, idx);
        return;
    }

    
    ledc_fade_mode_t fade_mode = LEDC_FADE_NO_WAIT; //non blocking
    /*ledc_fade_mode_t fade_mode = LEDC_FADE_WAIT_DONE; //blocking */
    err = ledc_fade_start(ledc_channel[idx].speed_mode,
                    ledc_channel[idx].channel, fade_mode);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) starting fade duty %d on channel %d",
            esp_err_to_name(err), duty, idx);
        return;
    }

    log_msg(TAG, "Starting fade : %d, on channel %d", duty, idx);
    xSemaphoreTake(counting_sem, portMAX_DELAY);
}
