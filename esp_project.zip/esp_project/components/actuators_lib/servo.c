

#if CONFIG_USE_MG996R



//global variables
static uint8_t current_angle = 0;

static ledc_timer_config_t ledc_timer_mg = {
    .duty_resolution = MG_RESOLUTION, // resolution of PWM duty : 0..8191
    .freq_hz = MG_FREQ,                      // frequency of PWM signal : 20ms
    .speed_mode = MG_SPEED_MODE,           // timer mode
    .timer_num = MG_TIMER,            // timer index
    .clk_cfg = LEDC_AUTO_CLK,              // Auto select the source clock
};
#endif