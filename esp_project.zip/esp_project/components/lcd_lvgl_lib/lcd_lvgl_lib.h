#ifndef LCD_LVGL_LIB_H_
#define LCD_LVGL_LIB_H_

#include <stdio.h>
#include <inttypes.h>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "driver/i2c_master.h"
#include "esp_system.h"
#include "esp_log.h"
#include "mqttLib.h"
#include "nvsLib.h"

void lcd_init();

void set_bar_steer(const int32_t v);

void set_bar_motor(const int32_t v);

void set_label_ip(const char* ip_str);

#endif