static ledc_timer_config_t ledc_timer_buzzer = {
    .duty_resolution = BUZZER_RESOLUTION, // resolution of PWM duty : 0..8191
    .freq_hz = BUZZER_START_FREQ,                      // frequency of PWM signal : 20ms
    .speed_mode = BUZZER_SPEED_MODE,           // timer mode
    .timer_num = BUZZER_LEDC_TIMER,            // timer index
    .clk_cfg = LEDC_AUTO_CLK,              // Auto select the source clock
};