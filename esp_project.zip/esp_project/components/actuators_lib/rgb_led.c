static ledc_timer_config_t ledc_timer_ky009 = {
    .duty_resolution = KY009_RESOLUTION, // resolution of PWM duty : 0..8191
    .freq_hz = KY009_FREQ,                      // frequency of PWM signal : 20ms
    .speed_mode = KY009_SPEED_MODE,           // timer mode
    .timer_num = KY009_LEDC_TIMER,            // timer index
    .clk_cfg = LEDC_AUTO_CLK,              // Auto select the source clock
};