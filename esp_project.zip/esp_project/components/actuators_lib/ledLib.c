#include "ledLib.h"
#include "driver/gpio.h"
#include <inttypes.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "nvsLib.h"
#include "logLib.h"
#include <stdarg.h>
#include <esp_err.h>
#include "driver/ledc.h"
#include "screenLib.h"
#include "esp_timer.h"
#include "h_bridge.h"
#include "servo.h"
#include "simple_led.h"
#include "two_color_led.h"
#include "buzzer.h"
#include "rgb_led.h"
#include "addr_rgb_led.h"
#include "debug_helper.h"

#define USE_LVGL_SCREEN 0

#if USE_LVGL_SCREEN
#include "lcdLib.h"
#endif

#if CONFIG_DEBUG_GPIO || CONFIG_DEBUG_LEDC
#include "soc/soc_caps.h"
#endif

#if CONFIG_DEBUG_LEDC
#include "hal/ledc_types.h"
#include "soc/ledc_struct.h"
#include "soc/clk_tree_defs.h"
#include "esp_clk_tree.h"
#endif

#if CONFIG_DEBUG_GPIO
#include "hal/gpio_types.h"
#include "esp_private/esp_gpio_reserve.h"
#endif

#include "driver/rmt_tx.h"

// Total secure sum
#define LEDC_CHANNELS_COUNT (BTS7960_CHANNELS + KY006_CHANNELS + MG996R_CHANNELS + KY029_CHANNELS + KY009_CHANNELS)

//idx for channels
#if CONFIG_USE_MG996R
#define DIRECTION_IDX  BTS7960_CHANNELS
#endif
#if CONFIG_USE_KY006
#define BUZZER_IDX     BTS7960_CHANNELS + MG996R_CHANNELS
#endif
#if CONFIG_USE_KY029
#define KY029_RED_IDX     BTS7960_CHANNELS + MG996R_CHANNELS + KY006_CHANNELS
#define KY029_GREEN_IDX     BTS7960_CHANNELS + MG996R_CHANNELS + KY006_CHANNELS + 1
#endif
#if CONFIG_USE_KY009
#define KY009_RED_IDX     BTS7960_CHANNELS + MG996R_CHANNELS + KY006_CHANNELS
#define KY009_GREEN_IDX     BTS7960_CHANNELS + MG996R_CHANNELS + KY006_CHANNELS + 1
#define KY009_BLUE_IDX     BTS7960_CHANNELS + MG996R_CHANNELS + KY006_CHANNELS + 2
#endif

/*
* Prepare individual configuration
* for each channel of LED Controller
* by selecting:
* - controller's channel number
* - output duty cycle, set initially to 0
* - GPIO number where LED is connected to
* - speed mode, either high or low
* - timer servicing selected channel
*   Note: if different channels use one timer,
*         then frequency and bit_num of these channels
*         will be the same
*/
static ledc_channel_config_t ledc_channel[LEDC_CHANNELS_COUNT] = {
#if CONFIG_USE_BTS7960
    {
        .channel    = BTS_CHANNEL_FWD,
        .duty       = 0,
        .gpio_num   = BTS_GPIO_FWD,
        .speed_mode = BTS_SPEED_MODE,
        .hpoint     = 0,
        .timer_sel  = BTS_TIMER,
        .flags.output_invert = 0
    },
    {
        .channel    = BTS_CHANNEL_BWD,
        .duty       = 0,
        .gpio_num   = BTS_GPIO_BWD,
        .speed_mode = BTS_SPEED_MODE,
        .hpoint     = 0,
        .timer_sel  = BTS_TIMER,
        .flags.output_invert = 0
    },
#endif
#if CONFIG_USE_MG996R
    {
        .channel    = MG_CHANNEL,
        .duty       = 0,
        .gpio_num   = MG_GPIO,
        .speed_mode = MG_SPEED_MODE,
        .hpoint     = 0,
        .timer_sel  = MG_TIMER,
        .flags.output_invert = 0
    },
#endif
#if CONFIG_USE_KY006
    {
        .channel             = BUZZER_LEDC_CHANNEL,     
        .duty                = 0,                   
        .gpio_num            = BUZZER_GPIO,         
        .speed_mode          = BUZZER_SPEED_MODE, 
        .hpoint              = 0,
        .timer_sel           = BUZZER_LEDC_TIMER,     
        .flags.output_invert = 0
    },
#endif
#if CONFIG_USE_KY029
    {
        .channel             = KY029_RED_CHANNEL,     
        .duty                = 0,                   
        .gpio_num            = KY029_RED_GPIO,         
        .speed_mode          = KY029_SPEED_MODE, 
        .hpoint              = 0,
        .timer_sel           = KY029_LEDC_TIMER,     
        .flags.output_invert = 0
    },
    {
        .channel             = KY029_GREEN_CHANNEL,     
        .duty                = 0,                   
        .gpio_num            = KY029_GREEN_GPIO,         
        .speed_mode          = KY029_SPEED_MODE, 
        .hpoint              = 0,
        .timer_sel           = KY029_LEDC_TIMER,     
        .flags.output_invert = 0
    },
#endif
#if CONFIG_USE_KY009
    {
        .channel             = KY009_RED_CHANNEL,     
        .duty                = 0,                   
        .gpio_num            = KY009_RED_GPIO,         
        .speed_mode          = KY009_SPEED_MODE, 
        .hpoint              = 0,
        .timer_sel           = KY009_LEDC_TIMER,     
        .flags.output_invert = 0
    },
    {
        .channel             = KY009_GREEN_CHANNEL,     
        .duty                = 0,                   
        .gpio_num            = KY009_GREEN_GPIO,         
        .speed_mode          = KY009_SPEED_MODE, 
        .hpoint              = 0,
        .timer_sel           = KY009_LEDC_TIMER,     
        .flags.output_invert = 0
    },
    {
        .channel             = KY009_BLUE_CHANNEL,     
        .duty                = 0,                   
        .gpio_num            = KY009_BLUE_GPIO,         
        .speed_mode          = KY009_SPEED_MODE, 
        .hpoint              = 0,
        .timer_sel           = KY009_LEDC_TIMER,     
        .flags.output_invert = 0
    },
#endif
};



/**
 * Apply duty
 * -Set & update duty
 */
static void ledc_duty(const uint32_t duty, const uint8_t idx) {

    esp_err_t err;

    if (idx > LEDC_CHANNELS_COUNT) {
        log_msg(TAG, "Out of bounds");
        return;
    }

    err = ledc_set_duty(ledc_channel[idx].speed_mode, ledc_channel[idx].channel, duty);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) setting duty %d on channel %d",
            esp_err_to_name(err), duty, idx);
        return;
    }

    err = ledc_update_duty(ledc_channel[idx].speed_mode, ledc_channel[idx].channel);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) updating duty %d on channel %d",
            esp_err_to_name(err), duty, idx);
        return;
    }

    log_msg_lvl(ESP_LOG_DEBUG, TAG, "Duty : %d, on channel %d", duty, idx);
}




/**
 * Close led
 * -Stop ledc channels, fade, timers
 * -Destroy mutex
 */
void close_led() {
#if CONFIG_USE_BUILTIN_LED
    if (xMutex == NULL) {
        log_msg(TAG, "Error on mutex creation");
        return;
    }
#endif

    //destroy ledc
    esp_err_t err;
    for (int i = 0; i < LEDC_CHANNELS_COUNT; i++) {
        //idle level to 0 = LOW?
        err = ledc_stop(ledc_channel[i].speed_mode, ledc_channel[i].channel, 0);
        if (err != ESP_OK) {
            log_msg(TAG, "Error (%s) on stop ledc channel %d", esp_err_to_name(err), i);
        }
    }
    ledc_fade_func_uninstall();

#if CONFIG_USE_MG996R
    err = ledc_timer_rst(ledc_timer_mg.speed_mode, ledc_timer_mg.timer_num);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) on reset ledc timer MG", esp_err_to_name(err));
    }
#endif
#if CONFIG_USE_KY006
    err = ledc_timer_rst(ledc_timer_buzzer.speed_mode, ledc_timer_buzzer.timer_num);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) on reset ledc timer buzzer", esp_err_to_name(err));
    }
#endif
#if CONFIG_USE_KY029
    err = ledc_timer_rst(ledc_timer_ky029.speed_mode, ledc_timer_ky029.timer_num);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) on reset ledc timer ky029", esp_err_to_name(err));
    }
#endif
#if CONFIG_USE_KY009
    err = ledc_timer_rst(ledc_timer_ky009.speed_mode, ledc_timer_ky009.timer_num);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) on reset ledc timer ky029", esp_err_to_name(err));
    }
#endif

#if CONFIG_USE_MG996R
    err = ledc_timer_pause(ledc_timer_mg.speed_mode, ledc_timer_mg.timer_num);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) on pause ledc timer MG", esp_err_to_name(err));
    }
#endif
#if CONFIG_USE_KY006
    err = ledc_timer_pause(ledc_timer_buzzer.speed_mode, ledc_timer_buzzer.timer_num);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) on pause ledc timer buzzer", esp_err_to_name(err));
    }
#endif
#if CONFIG_USE_KY029
    err = ledc_timer_pause(ledc_timer_ky029.speed_mode, ledc_timer_ky029.timer_num);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) on pause ledc timer ky029", esp_err_to_name(err));
    }
#endif
#if CONFIG_USE_KY009
    err = ledc_timer_pause(ledc_timer_ky009.speed_mode, ledc_timer_ky009.timer_num);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) on pause ledc timer ky029", esp_err_to_name(err));
    }
#endif

    if (counting_sem != NULL) {
        vSemaphoreDelete(counting_sem);
        counting_sem = NULL;
    }

#if CONFIG_USE_BUILTIN_LED
    vSemaphoreDelete(xMutex);
    xMutex = NULL;
#endif

    log_msg(TAG, "Led & Ledc closed");
}

/**
 * Init ledc
 * -Init timers, channels, fade, count semaphore & register fade callback
 */
void init_ledc() {

    esp_err_t err;
    int ch;

#if CONFIG_USE_MG996R
    err = ledc_timer_config(&ledc_timer_mg);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) setting timer for MG", esp_err_to_name(err));
        return;
    }
#endif

#if CONFIG_USE_KY006
    err = ledc_timer_config(&ledc_timer_buzzer);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) setting timer for buzzer", esp_err_to_name(err));
        return;
    }
#endif
#if CONFIG_USE_KY029
    err = ledc_timer_config(&ledc_timer_ky029);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) setting timer for KY-029", esp_err_to_name(err));
        return;
    }
#endif
#if CONFIG_USE_KY009
    err = ledc_timer_config(&ledc_timer_ky009);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) setting timer for KY-009", esp_err_to_name(err));
        return;
    }
#endif

    // Set LED Controller with previously prepared configuration
    for (ch = 0; ch < LEDC_CHANNELS_COUNT; ch++) {
        err = ledc_channel_config(&ledc_channel[ch]);
        if (err != ESP_OK) {
            log_msg(TAG, "Error (%s) setting channel %d",
                esp_err_to_name(err), ch);
            return;
        }
    }

    // Initialize fade service.
    init_fade_led(ledc_channel);

    log_msg(TAG, "LEDC initialized");

#if CONFIG_DEBUG_LEDC || CONFIG_DEBUG_GPIO
    print_esp_info_ledc();
#endif
}

void init_all_gpios() {

    led_init();
    init_ledc();

    #if CONFIG_USE_BUILTIN_LED_W2812B
    init_ws2812_rmt();
    #endif
}



/**
 * Get current angle of servo
 */
esp_err_t get_servo_angle(uint8_t* angle) {
#if CONFIG_USE_MG996R
    *angle = current_angle;
    return ESP_OK;
#else
    return ESP_FAIL;
#endif
}

/**
 * Apply a ledc angle for MG servo
 * -Clamp value, check if the value changed, transform angle to duty & apply it
 * -Write to screen if set
 */
void ledc_angle(int16_t angle) {
#if CONFIG_USE_MG996R
    //clamp
    if (angle < 0) angle = 0;
    if (angle > 180) angle = 180;

    if (current_angle != angle) {
        current_angle = angle;

        //applying duty
        ledc_duty(
            MIN_SERVO_DUTY + ((MAX_SERVO_DUTY - MIN_SERVO_DUTY) * angle) / 180, DIRECTION_IDX
        );

        log_msg(TAG, "Angle : %d, on pin %d", angle, MG_GPIO);

#if CONFIG_WRITE_ANGLE_SCREEN

#if USE_LVGL_SCREEN
        set_bar_steer((current_angle - 90) * 200 / 180);
#else
        //print to screen
        char tmp[30];
        snprintf(tmp, sizeof(tmp), "Angle : %d", current_angle);
        ssd1306_draw_string(tmp, 0, 2);
#endif
#endif
    }
#endif
    
}




void ledc_buzzer(int16_t buzzer_percent) {

    #if CONFIG_USE_KY006
    //clamp
    if (buzzer_percent < 0) buzzer_percent = 0;
    if (buzzer_percent > 100) buzzer_percent = 100; 

    ledc_duty(
            BUZZER_MIN_DUTY + ((BUZZER_MAX_DUTY - BUZZER_MIN_DUTY) * buzzer_percent) / 100, BUZZER_IDX
        );
    
    ESP_LOGI(TAG, "apply duty %u", BUZZER_MIN_DUTY + ((BUZZER_MAX_DUTY - BUZZER_MIN_DUTY) * buzzer_percent) / 100);
    #endif
    
}

void ledc_ky029(int16_t ky029_percent, const bool red) {

    #if CONFIG_USE_KY029
    //clamp
    if (ky029_percent < 0) ky029_percent = 0;
    if (ky029_percent > 100) ky029_percent = 100; 

    ledc_duty(
            KY029_MIN_DUTY + ((KY029_MAX_DUTY - KY029_MIN_DUTY) * ky029_percent) / 100, 
            red ? KY029_RED_IDX : KY029_GREEN_IDX
        );
    
    ESP_LOGI(TAG, "apply duty %u", KY029_MIN_DUTY + ((KY029_MAX_DUTY - KY029_MIN_DUTY) * ky029_percent) / 100);
    #endif
    
}

void ledc_ky009(int16_t ky009_percent, const uint8_t color) {

    #if CONFIG_USE_KY009
    //clamp
    if (ky009_percent < 0) ky009_percent = 0;
    if (ky009_percent > 100) ky009_percent = 100; 

    int8_t idx = -1;
    switch (color)
    {
    case 0:
        idx = KY009_RED_IDX;
        break;
    case 1:
        idx = KY009_GREEN_IDX;
        break;
    case 2:
        idx = KY009_BLUE_IDX;
        break;
    
    default:
        break;
    }

    if (idx != -1) {
        ledc_duty(
            KY009_MIN_DUTY + ((KY009_MAX_DUTY - KY009_MIN_DUTY) * ky009_percent) / 100, 
            idx
        );
    
        ESP_LOGI(TAG, "apply duty %u", KY009_MIN_DUTY + ((KY009_MAX_DUTY - KY009_MIN_DUTY) * ky009_percent) / 100);
    }

    #endif
    
}

/*
==========================
other functions for ledc
==========================
*/

//ledc_set_pin to configure channel config better
//ledc_set_freq

//ledc_set_duty_and_update
//ledc_set_duty_with_hpoint;

//ledc_set_fade
//ledc_set_fade_with_step
//ledc_set_fade_step_and_start
//ledc_set_fade_time_and_start

//ledc_isr_register (deprecated)

//ledc_timer_resume
//ledc_bind_channel_timer (deprecated)

/*
==========================
other functions for gpio
==========================
*/

//TODO : change gpio_reset to gpio_config to control everything

/*for interruptions rising / falling edges, in input mode*/
//gpio_set_intr_type
//gpio_intr_enable
//gpio_intr_disable
//gpio_isr_register
//gpio_install_isr_service
//gpio_uninstall_isr_service
//gpio_isr_handler_add
//gpio_isr_handler_remove

/*for gpio config*/
//gpio_config
//gpio_input_enable
//gpio_set_pull_mode
//gpio_wakeup_enable
//gpio_wakeup_disable
//gpio_pullup_en
//gpio_pullup_dis
//gpio_pulldown_en
//gpio_pulldown_dis
//gpio_output_enable
//gpio_output_disable
//gpio_od_enable
//gpio_od_disable
//gpio_set_drive_capability
//gpio_hold_en
//gpio_hold_dis
//gpio_deep_sleep_hold_en
//gpio_deep_sleep_hold_dis
//gpio_sleep_sel_en
//gpio_sleep_sel_dis
//gpio_sleep_set_direction
//gpio_sleep_set_pull_mode

//rtc gpios : for sleep-active gpios
