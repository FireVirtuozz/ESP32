#if CONFIG_USE_BUILTIN_LED_W2812B
#define LED_GPIO             48
#define RMT_CLK_RES_HZ       10000000 // Horloge à 10MHz -> 1 tick = 100ns

// Définition de nos timings en nombre de ticks
#define T0H  4   // 400ns à l'état HAUT
#define T0L  8   // 800ns à l'état BAS
#define T1H  8   // 800ns à l'état HAUT
#define T1L  4   // 400ns à l'état BAS

static rmt_channel_handle_t tx_chan = NULL;
static rmt_encoder_handle_t copy_encoder = NULL;

static void init_ws2812_rmt(void) {
    // 1. Configuration du canal matériel RMT TX
    rmt_tx_channel_config_t tx_chan_config = {
        .clk_src = RMT_CLK_SRC_DEFAULT,
        .gpio_num = LED_GPIO,
        .mem_block_symbols = 64,        // Buffer interne suffisant pour 1 LED (24 bits)
        .resolution_hz = RMT_CLK_RES_HZ,
        .trans_queue_depth = 4,
    };
    rmt_new_tx_channel(&tx_chan_config, &tx_chan);

    // 2. Initialisation de l'encodeur "Copy" d'ESP-IDF
    // Il va copier notre tableau de symboles directement vers la mémoire du RMT
    rmt_copy_encoder_config_t copy_encoder_config = {};
    rmt_new_copy_encoder(&copy_encoder_config, &copy_encoder);

    // 3. Activation du canal matériel
    rmt_enable(tx_chan);

    log_msg(TAG, "BUILTIN W2812B initialized");
}

#endif

void set_led_color(uint8_t r, uint8_t g, uint8_t b) {

#if CONFIG_USE_BUILTIN_LED_W2812B
    // ATTENTION : Le WS2812B attend les couleurs dans l'ordre G-R-B (Vert, Rouge, Bleu)
    // On fusionne les trois octets dans un seul entier 24 bits
    uint32_t color_val = ((uint32_t)g << 16) | ((uint32_t)r << 8) | b;

    // 1 LED = 24 bits = Il nous faut un tableau de 24 symboles RMT
    rmt_symbol_word_t led_symbols[24];

    // On boucle sur les 24 bits, du plus fort (MSB) au plus faible (LSB)
    for (int i = 0; i < 24; i++) {
        // Extraction du bit courant (0 ou 1)
        uint32_t bit = (color_val >> (23 - i)) & 0x01;

        if (bit == 0) {
            // Configuration de la vague pour un bit '0'
            led_symbols[i] = (rmt_symbol_word_t) {
                .duration0 = T0H, .level0 = 1, // Reste HAUT pendant T0H ticks
                .duration1 = T0L, .level1 = 0  // Puis passe BAS pendant T0L ticks
            };
        } else {
            // Configuration de la vague pour un bit '1'
            led_symbols[i] = (rmt_symbol_word_t) {
                .duration0 = T1H, .level0 = 1, // Reste HAUT pendant T1H ticks
                .duration1 = T1L, .level1 = 0  // Puis passe BAS pendant T1L ticks
            };
        }
    }

    // Configuration de la transmission
    rmt_transmit_config_t transmit_config = {
        .loop_count = 0, // On envoie une seule fois
    };

    // Transmission des données (la taille demandée doit être en octets !)
    rmt_transmit(tx_chan, copy_encoder, led_symbols, sizeof(led_symbols), &transmit_config);
    
    // Attente synchrone que le RMT ait fini de cracher les bits sur la pin
    rmt_tx_wait_all_done(tx_chan, portMAX_DELAY);

    log_msg(TAG, "W2812B color set to: %u,%u,%u [RGB]", r, g, b);
#endif
}