#ifndef ADDR_RGB_LED_H_
#define ADDR_RGB_LED_H_

//WS2812: Adressing RGB LED, commonly used as ESPs Built-in LEDs 

#endif