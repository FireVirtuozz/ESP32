//LED pin gpio connected on breadboard
#define LED_PIN 2


static int led_state = 0; //TODO : convert to uint8
//mutex for changes to global variables
static SemaphoreHandle_t xMutex = NULL;


/**
 * Led on : set level of gpio to HIGH and save it to nvs
 */
void led_on() {

#if CONFIG_USE_BUILTIN_LED
    if (xMutex == NULL) {
        log_msg(TAG, "Error on mutex creation");
        return;
    }

    if (xSemaphoreTake(xMutex, portMAX_DELAY) == pdTRUE) {
        if (led_state == 0) {
            led_state = 1;
            esp_err_t err = gpio_set_level(LED_PIN, led_state);
            if (err != ESP_OK) {
                log_msg_lvl(ESP_LOG_ERROR, TAG, "Error (%s) setting level on pin : %d", esp_err_to_name(err), LED_PIN);
                xSemaphoreGive(xMutex);
                return;
            }
        #if CONFIG_SAVE_LED
            err = save_nvs_int("led_state", led_state);
            if (err != ESP_OK) {
                log_msg_lvl(ESP_LOG_ERROR, TAG, "Error (%s) loading saving led_state in nvs", esp_err_to_name(err));
                xSemaphoreGive(xMutex);
                return;
            }
        #endif
            log_msg(TAG, "Led on");
        }
        xSemaphoreGive(xMutex);
    }
#endif
}

/**
 * Led off : set level of gpio to LOW and save it to nvs
 */
void led_off() {
#if CONFIG_USE_BUILTIN_LED
    if (xMutex == NULL) {
        log_msg(TAG, "Error on mutex creation");
        return;
    }

    if (xSemaphoreTake(xMutex, portMAX_DELAY) == pdTRUE) {
        if (led_state != 0) {
            led_state = 0;
            esp_err_t err = gpio_set_level(LED_PIN, led_state);
            if (err != ESP_OK) {
                log_msg(TAG, "Error (%s) setting level on pin : %d", esp_err_to_name(err), LED_PIN);
                xSemaphoreGive(xMutex);
                return;
            }
    #if CONFIG_SAVE_LED
            err = save_nvs_int("led_state", led_state);
            if (err != ESP_OK) {
                log_msg(TAG, "Error (%s) loading saving led_state in nvs", esp_err_to_name(err));
                xSemaphoreGive(xMutex);
                return;
            }
    #endif
            log_msg(TAG, "Led off");
        }
        xSemaphoreGive(xMutex);
    }
#endif
}

/**
 * Led toggle : reverse level and save it to nvs
 */
void led_toggle() {
#if CONFIG_USE_BUILTIN_LED
    if (xMutex == NULL) {
        log_msg(TAG, "Error on mutex creation");
        return;
    }

    if (xSemaphoreTake(xMutex, portMAX_DELAY) == pdTRUE) {
        led_state = !led_state;
        esp_err_t err = gpio_set_level(LED_PIN, led_state);
        if (err != ESP_OK) {
            log_msg(TAG, "Error (%s) setting level on pin : %d", esp_err_to_name(err), LED_PIN);
            xSemaphoreGive(xMutex);
            return;
        }
    #if CONFIG_SAVE_LED
        err = save_nvs_int("led_state", led_state);
        if (err != ESP_OK) {
            log_msg(TAG, "Error (%s) loading saving led_state in nvs", esp_err_to_name(err));
            xSemaphoreGive(xMutex);
            return;
        }
    #endif
        log_msg(TAG, "Led toggled to : %d", led_state);
        xSemaphoreGive(xMutex);
    }
#endif
}

/**
 * Get led state
 * @return int current led state, -1 if error
 */
int get_led_state() {

    int led = -1;
#if CONFIG_USE_BUILTIN_LED
    if (xMutex == NULL) {
        log_msg(TAG, "Error on mutex creation");
        return led;
    }

    if (xSemaphoreTake(xMutex, portMAX_DELAY) == pdTRUE) {
        led = led_state;
        xSemaphoreGive(xMutex);
    }
#endif
    return led;
}

/**
 * Initalize led
 * -Initialize mutex
 * -Reset pin
 * -Set output mode
 * -Load previous state in nvs and apply it
 */
void led_init() {
#if CONFIG_USE_BUILTIN_LED
    if( xMutex != NULL )
    {
        log_msg(TAG, "Mutex already initialized");
        return;
    }

    xMutex = xSemaphoreCreateMutex();

    if( xMutex == NULL )
    {
        log_msg(TAG, "Error on mutex creation");
        return;
    }

    //reset gpio pin
    esp_err_t err = gpio_reset_pin(LED_PIN);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) resetting pin %d", esp_err_to_name(err), LED_PIN);
        return;
    }

    //set output mode for gpio
    err = gpio_set_direction(LED_PIN, GPIO_MODE_OUTPUT);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) setting direction pin %d", esp_err_to_name(err), LED_PIN);
        return;
    }
#if CONFIG_SAVE_LED
    //load led state in nvs and apply it to gpio
    err = load_nvs_int("led_state", &led_state);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) loading nvs int : led_state", esp_err_to_name(err));
        return;
    }
#endif
    err = gpio_set_level(LED_PIN, led_state);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) setting level on pin : %d", esp_err_to_name(err), LED_PIN);
        return;
    }

    log_msg(TAG, "Led initialized on pin %d", LED_PIN);
#endif

}