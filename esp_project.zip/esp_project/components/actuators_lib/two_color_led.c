static ledc_timer_config_t ledc_timer_ky029 = {
    .duty_resolution = KY029_RESOLUTION, // resolution of PWM duty : 0..8191
    .freq_hz = KY029_FREQ,                      // frequency of PWM signal : 20ms
    .speed_mode = KY029_SPEED_MODE,           // timer mode
    .timer_num = KY029_LEDC_TIMER,            // timer index
    .clk_cfg = LEDC_AUTO_CLK,              // Auto select the source clock
};