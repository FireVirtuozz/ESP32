#ifndef H_BRIDGE_H_
#define H_BRIDGE_H_

// BTS7960: DC Brushed Motor H-Bridge controller BTS7960

#include <inttypes.h>
#include <esp_err.h>
#include "ledLib.h"

//for h-bridge bts7960
#define BTS_TIMER           LEDC_TIMER_0
#if CONFIG_IDF_TARGET_ESP32
#define BTS_SPEED_MODE      LEDC_HIGH_SPEED_MODE
#else
#define BTS_SPEED_MODE      LEDC_LOW_SPEED_MODE
#endif
#define BTS_GPIO_FWD        41
#define BTS_CHANNEL_FWD     LEDC_CHANNEL_0
#define BTS_GPIO_BWD        42
#define BTS_CHANNEL_BWD     LEDC_CHANNEL_1
#define BTS_FREQ            20000 //max frequency BTS : 25kHz
#define BTS_RESOLUTION      LEDC_TIMER_11_BIT

#if CONFIG_USE_BTS7960
    #define BTS7960_CHANNELS 2
#else
    #define BTS7960_CHANNELS 0
#endif


esp_err_t init_bts();

esp_err_t close_bts();

#endif