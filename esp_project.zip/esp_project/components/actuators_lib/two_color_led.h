#ifndef TWO_COLOR_LED_H_
#define TWO_COLOR_LED_H_

#include "ledLib.h"

//KY029: small two-color LED powered by PWM (red / green)

#define KY029_RED_GPIO          18  // À adapter selon ton câblage
#define KY029_GREEN_GPIO        19   // À adapter selon ton câblage
#define KY029_RESOLUTION        LEDC_TIMER_13_BIT
#define KY029_FREQ              5000 // 5 kHz (parfait pour les LEDs, aucun scintillement)
#define KY029_MIN_DUTY          0
#define KY029_MAX_DUTY          GET_MAX_DUTY(KY029_RESOLUTION) // 100% de luminosité (pas divisé par 2 !)
#define KY029_SPEED_MODE        LEDC_LOW_SPEED_MODE
#define KY029_LEDC_TIMER        LEDC_TIMER_3  // Nouveau timer (car fréquence différente du buzzer)
#define KY029_RED_CHANNEL       LEDC_CHANNEL_5
#define KY029_GREEN_CHANNEL     LEDC_CHANNEL_6

#if CONFIG_USE_KY029
    #define KY029_CHANNELS 2
#else
    #define KY029_CHANNELS 0
#endif

#endif