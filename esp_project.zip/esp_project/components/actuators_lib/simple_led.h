#ifndef SIMPLE_LED_H_
#define SIMPLE_LED_H_

// Simple on/off LED

#endif