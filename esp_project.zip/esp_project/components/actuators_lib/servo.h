#ifndef SERVO_H_
#define SERVO_H_

// MG996R: Powerful basic servo-motor.

#include "ledLib.h"


#define MG_TIMER            LEDC_TIMER_1
#if CONFIG_IDF_TARGET_ESP32
#define MG_SPEED_MODE       LEDC_HIGH_SPEED_MODE
#else
#define MG_SPEED_MODE       LEDC_LOW_SPEED_MODE
#endif
#define MG_GPIO             (7) //parentheses reliable to avoid bugs in calculus
#define MG_CHANNEL          LEDC_CHANNEL_2
#define MG_FREQ             50 //50 Hz for mg996r
#if CONFIG_IDF_TARGET_ESP32
#define MG_RESOLUTION       LEDC_TIMER_15_BIT
#else
#define MG_RESOLUTION       LEDC_TIMER_14_BIT
#endif

//mg996r
#if CONFIG_IDF_TARGET_ESP32
#define MIN_SERVO_DUTY 1638
#define MAX_SERVO_DUTY 3277
#else
#define MIN_SERVO_DUTY 969
#define MAX_SERVO_DUTY 1489
#endif

// 3. Détermination pour le MG996R (1 canal si activé, 0 sinon)
#if CONFIG_USE_MG996R
    #define MG996R_CHANNELS 1
#else
    #define MG996R_CHANNELS 0
#endif

#endif