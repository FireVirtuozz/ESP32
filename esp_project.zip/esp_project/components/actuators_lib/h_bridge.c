#include "bts7960.h"


#if CONFIG_USE_BTS7960

#include <stdatomic.h>
#include "ledLib.h"
#include <math.h>


//bts7960
#define DEADZONE_MOTOR 50
#define MIN_MOTOR_DUTY_FWD 0
#define MAX_MOTOR_DUTY_FWD GET_MAX_DUTY(BTS_RESOLUTION) //max duty : 2^resolution - 1
#define MIN_MOTOR_DUTY_BWD 0
#define MAX_MOTOR_DUTY_BWD GET_MAX_DUTY(BTS_RESOLUTION)



/*
* Prepare and set configuration of timers
* that will be used by LED Controller
*/
static ledc_timer_config_t ledc_timer_bts = {
    .duty_resolution = BTS_RESOLUTION, // resolution of PWM duty : 0..8191
    .freq_hz = BTS_FREQ,                      // frequency of PWM signal : 20ms
    .speed_mode = BTS_SPEED_MODE,           // timer mode
    .timer_num = BTS_TIMER,            // timer index
    .clk_cfg = LEDC_AUTO_CLK,              // Auto select the source clock
};

#define MOTOR_IDX_FWD  0
#define MOTOR_IDX_BWD  1

static atomic_bool breaking_lock = false;
static volatile bool hc_block_activated = false;

#if CONFIG_USE_UDPLIB && CONFIG_USE_SENSORS
#include "udpLib.h"  
#include "sensorsLib.h"
#endif

#define MOTOR_CTRL_PERIOD 20000

typedef enum { 
    CURVE_LINEAR = 0, 
    CURVE_EXP = 1, 
    CURVE_COSINE = 2 
} CurveType;

#define MOTOR_FRAME_SIZE 8

typedef struct {
    uint8_t curve_type;
    uint8_t accel_param;   // 0-255, sens dépend du curve_type
    uint8_t decel_param;   // idem, séparé (asymétrie accel/frein)
} DriveProfileConfig;

void serialize_motor(DriveProfileConfig *cfg, uint8_t* buf) {
    buf[0] = cfg->curve_type;
    buf[1] = cfg->accel_param;
    buf[2] = cfg->decel_param;
    int16_t curr = current_motor;
    int16_t targ = target_motor;
    memcpy(&buf[3], &curr, sizeof(int16_t));
    memcpy(&buf[5], &targ, sizeof(int16_t));
    buf[7] = (uint8_t)hc_block_activated;
}

static uint32_t timeout_breaking = 0;

#define BREAKING_FRAME_SIZE (sizeof(uint8_t) + sizeof(uint32_t) + 2 * sizeof(uint16_t) + sizeof(int16_t)) //11

void serialize_breaking(
    uint8_t* buf, bool breaking, uint16_t pulses_100ms, uint16_t pulses_20ms
) {
    buf[0] = (uint8_t)breaking;
    memcpy(&buf[1], &timeout_breaking, sizeof(uint32_t));
    memcpy(&buf[5], &pulses_100ms, sizeof(uint16_t));
    memcpy(&buf[7], &pulses_20ms, sizeof(uint16_t));
    int16_t curr = current_motor;
    memcpy(&buf[9], &curr, sizeof(int16_t));
}

static DriveProfileConfig cfg = { CURVE_COSINE, 180, 190 };
static int32_t ramp_start_motor = 0;
static uint32_t ramp_tick = 0;

static int32_t apply_curve_step(int32_t current, int32_t target, uint8_t param, uint8_t curve_type) {
    int32_t delta = target - current;
    if (delta == 0) return current;

    switch (curve_type) {
        case CURVE_LINEAR: {
            int32_t step = (delta > 0) ? param : -param;
            int32_t next = current + step;
            return (delta > 0) ? (next > target ? target : next) : (next < target ? target : next);
        }
        case CURVE_EXP: {
            float alpha = param / 255.0f;
            return current + (int32_t)(delta * alpha);
        }
        case CURVE_COSINE: {
            ramp_tick++;
            uint32_t total_ticks = 200 - param; // param haut = rampe courte/nerveuse
            if (total_ticks < 1) total_ticks = 1;
            float t = (float)ramp_tick / total_ticks;
            if (t > 1.0f) t = 1.0f;
            float s = (1.0f - cosf(M_PI * t)) / 2.0f;
            return ramp_start_motor + (int32_t)((target - ramp_start_motor) * s);
        }
    }
    return current;
}

static volatile int16_t current_motor = 0;
static volatile int16_t target_motor = 0;

static int32_t last_target = 0;
static int64_t timestamp_force_motor = 0;
static bool last_current_motor_sign_positive = false;

static void apply_target_motor(void* args) { 

    if (atomic_load(&breaking_lock)) {
        //after 2 seconds applying reverse target it is supposed to be stopped
        uint16_t pulses = 0;
        int64_t dt = esp_timer_get_time() - timestamp_force_motor;
        if (dt > timeout_breaking || (get_pulses_count_100ms(&pulses) == ESP_OK && pulses < 2)) {
            log_msg_lvl(ESP_LOG_WARN, TAG, "Breaking stopped [%s] 100ms pulses: %u, dt: %lld",
                dt > timeout_breaking ? "timeout" : "pulse", pulses, dt);
            target_motor = 0;
            atomic_store(&breaking_lock, false);
        #if CONFIG_USE_UDPLIB && CONFIG_USE_SENSORS
            uint16_t pulses_100ms, pulses_20ms;
            get_pulses_count_100ms(&pulses_100ms);
            get_pulses_count_20ms(&pulses_20ms);
            header_sensor_t header = {0};
            header.esp_id = (uint8_t)CONFIG_ESP_ID;
            header.timestamp = (uint32_t)(esp_timer_get_time() / 1000);
            header.type = SENSOR_TYPE_BREAK;
            uint8_t buf[HEADER_SENSOR_SIZE + BREAKING_FRAME_SIZE];
            serialize_header(&header, buf);
            serialize_breaking(&buf[HEADER_SENSOR_SIZE], false, pulses_100ms, pulses_20ms);
            send_udp_sensor(buf, sizeof(buf));
        #endif
        }
    }
    if (target_motor != last_target) {
        ramp_tick = 0;
        ramp_start_motor = current_motor;
        last_target = target_motor;
    }
    if (current_motor != target_motor) {

        bool is_accel = (target_motor > current_motor && current_motor >= 0) ||
            (target_motor < current_motor && current_motor <= 0);

        current_motor = apply_curve_step(current_motor, target_motor,
            is_accel ? cfg.accel_param : cfg.decel_param, cfg.curve_type);

        //applying duty forward et 0 backward
        if (current_motor > 0) {
            ledc_duty(
                MIN_MOTOR_DUTY_FWD + ((MAX_MOTOR_DUTY_FWD - MIN_MOTOR_DUTY_FWD) * current_motor) / 1000, MOTOR_IDX_FWD
            );
            ledc_duty(0, MOTOR_IDX_BWD);
            last_current_motor_sign_positive = true;
        }

        //applying duty backward et 0 forward
        else if (current_motor < 0) {
            ledc_duty(
                MIN_MOTOR_DUTY_BWD + ((MAX_MOTOR_DUTY_BWD - MIN_MOTOR_DUTY_BWD) * - current_motor) / 1000, MOTOR_IDX_BWD
            );
            ledc_duty(0, MOTOR_IDX_FWD);
            last_current_motor_sign_positive = false;
        }

        //applying 0 to backward & forward
        else {
            ledc_duty(0, MOTOR_IDX_FWD);
            ledc_duty(0, MOTOR_IDX_BWD);
        }
        
        log_msg(TAG, "Motor : %d/%d, on pins; fwd : %d, bwd : %d",
            current_motor, target_motor, BTS_GPIO_FWD, BTS_GPIO_BWD);

        #if CONFIG_WRITE_MOTOR_SCREEN

#if USE_LVGL_SCREEN
        set_bar_motor(current_motor);
#else
        //print to screen
        char tmp[30];
        snprintf(tmp, sizeof(tmp), "Motor : %d, Target: %d", current_motor, target_motor);
        ssd1306_draw_string(tmp, 0, 4);
#endif
#endif
    } else {
        ramp_tick = 0;
        ramp_start_motor = current_motor;
    }
    #if CONFIG_USE_UDPLIB && CONFIG_USE_SENSORS
        header_sensor_t header = {0};
        header.esp_id = (uint8_t)CONFIG_ESP_ID;
        header.timestamp = (uint32_t)(esp_timer_get_time() / 1000);
        header.type = SENSOR_TYPE_MOTOR;
        uint8_t buf[HEADER_SENSOR_SIZE + MOTOR_FRAME_SIZE];
        serialize_header(&header, buf);
        serialize_motor(&cfg, &buf[HEADER_SENSOR_SIZE]);
        send_udp_sensor(buf, sizeof(buf));
    #endif
}

esp_err_t apply_config(uint8_t *buf, uint8_t len) {
#if CONFIG_USE_BTS7960
    cfg.curve_type = buf[0];
    cfg.accel_param = buf[1];
    cfg.decel_param = buf[2];
    ramp_tick = 0;            
    ramp_start_motor = current_motor; 
    return ESP_OK;
#else
    return ESP_ERR_INVALID_STATE;
#endif
}

esp_err_t init_bts() {
    esp_err_t err;

    err = ledc_timer_config(&ledc_timer_bts);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) setting timer for BTS", esp_err_to_name(err));
        return err;
    }

        log_msg(TAG, "Setting up control timer");
    const esp_timer_create_args_t ctrl_timer_args = {
        .callback = &apply_target_motor,
        .name = "ctrl_timer"
    };
    esp_timer_handle_t ctrl_timer = NULL;
    err = esp_timer_create(&ctrl_timer_args, &ctrl_timer);
    if (err != ESP_OK) {
        log_msg_lvl(ESP_LOG_ERROR, TAG, "failed to create  control esp timer instance");
        return err;
    }
    err = esp_timer_start_periodic(ctrl_timer, MOTOR_CTRL_PERIOD);
    if (err != ESP_OK) {
        log_msg_lvl(ESP_LOG_ERROR, TAG, "failed to start periodic timer");
        return err;
    }

    return ESP_OK
}

esp_err_t close_bts() {
    esp_err_t err;

    err = ledc_timer_pause(ledc_timer_bts.speed_mode, ledc_timer_bts.timer_num);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) on pause ledc timer BTS", esp_err_to_name(err));
    }

    err = ledc_timer_rst(ledc_timer_bts.speed_mode, ledc_timer_bts.timer_num);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) on reset ledc timer BTS", esp_err_to_name(err));
    }

    return ESP_OK;
}

esp_err_t set_motor_percent(int16_t motor) {
    if (motor < -1000) motor = -1000;
    if (motor > 1000) motor = 1000; 
    target_motor = motor;
    return ESP_OK;
}

/**
 * Get current angle of servo
 */
esp_err_t get_motor_percent(int16_t* motor) {
    *motor = current_motor;
    return ESP_OK;
}

esp_err_t get_last_motor_sign_positive(bool* sign) {
    *sign = last_current_motor_sign_positive;
    return ESP_OK;
}

esp_err_t force_motor_stop() {
    if (!atomic_load(&breaking_lock)) {
        uint16_t pulses = 0;
        if (get_pulses_count_100ms(&pulses) != ESP_OK) {
            log_msg_lvl(ESP_LOG_ERROR, TAG, "Pulses count not available, breaking not triggered");
            return ESP_ERR_INVALID_STATE;
        } else {
            timestamp_force_motor = esp_timer_get_time();
            int16_t temp_motor = pulses * 34 + 100; //4 - resolution
            if (abs(current_motor) < 100 && pulses > 0) {
                // gas is released but inertia is still here
                //timeout_breaking = (pulses * 80 + 250) * 800;
                timeout_breaking = (pulses * 8 + 200) * 800; 
            } else {
                timeout_breaking = abs(current_motor) * 800;
            }
            log_msg_lvl(ESP_LOG_WARN, TAG, 
                "Breaking started, pulses: %u, target_motor_abs: %d, current_motor: %d, timeout: %u, last_sign: %s", 
                pulses, temp_motor, current_motor, timeout_breaking, 
                last_current_motor_sign_positive ? "+" : "-"
            );
            if (last_current_motor_sign_positive) {
                set_motor_percent(-1000);
            } else {
                set_motor_percent(1000);
            }
            atomic_store(&breaking_lock, true);
        #if CONFIG_USE_UDPLIB && CONFIG_USE_SENSORS
            uint16_t pulses_20ms;
            get_pulses_count_20ms(&pulses_20ms);
            header_sensor_t header = {0};
            header.esp_id = (uint8_t)CONFIG_ESP_ID;
            header.timestamp = (uint32_t)(esp_timer_get_time() / 1000);
            header.type = SENSOR_TYPE_BREAK;
            uint8_t buf[HEADER_SENSOR_SIZE + BREAKING_FRAME_SIZE];
            serialize_header(&header, buf);
            serialize_breaking(&buf[HEADER_SENSOR_SIZE], true, pulses, pulses_20ms);
            send_udp_sensor(buf, sizeof(buf));
        #endif
            return ESP_OK;
        }
    }
    return ESP_ERR_INVALID_STATE;
}



void activate_hc_blocking(bool active) {
    #if CONFIG_USE_BTS7960
    hc_block_activated = active;
    #endif
}

esp_err_t get_active_hc_blocking(bool* active) {
    *active = hc_block_activated;
    return ESP_OK;
}


/**
 * Apply a ledc motor for BTS
 * -Clamp value, check if the value changed, transform motor to duty & apply it
 * -Write to screen if set
 */
void ledc_motor(int16_t motor_percent) {
    if (!atomic_load(&breaking_lock)) {
        //clamp
        if (motor_percent < -1000) motor_percent = -1000;
        if (motor_percent > 1000) motor_percent = 1000; 

        //deadzone
        if (abs(motor_percent) < DEADZONE_MOTOR) {
            motor_percent = 0;
        }

        bool front, rear;
        if (get_front_blocked(&front) == ESP_OK && get_rear_blocked(&rear) == ESP_OK) {
            if ((motor_percent < 0 && front) || (motor_percent > 0 && rear)) {
                log_msg_lvl(ESP_LOG_WARN, TAG, "Cannot %s, blocked by a wall",
                motor_percent > 0 ? "reverse" : "forward");
            } else {
                target_motor = -motor_percent;
            }
        } else {
            target_motor = -motor_percent;
        }
        
    }
}

#endif





