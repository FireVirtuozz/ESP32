#if CONFIG_DEBUG_LEDC
static char * mode_str(const ledc_mode_t mode) {
    switch (mode)
    {
    case LEDC_HIGH_SPEED_MODE:
        return "High speed";
    case LEDC_LOW_SPEED_MODE:
        return "Low speed";
    case LEDC_SPEED_MODE_MAX:
        return "Max speed";
    default:
        return "Unknown";
    }
}

static char * itr_str(const ledc_intr_type_t type) {
    switch (type)
    {
    case LEDC_INTR_DISABLE:
        return "Disabled";
    case LEDC_INTR_FADE_END:
        return "Enabled";
    case LEDC_INTR_MAX:
        return "Max";
    default:
        return "Unknown";
    }
}

static char * sleep_str(const ledc_sleep_mode_t sleep) {
    switch (sleep)
    {
    case LEDC_SLEEP_MODE_NO_ALIVE_NO_PD:
        return "No alive, no PD";
    case LEDC_SLEEP_MODE_NO_ALIVE_ALLOW_PD:
        return "No alive, allow PD";
    case LEDC_SLEEP_MODE_KEEP_ALIVE:
        return "Keep alive";
    case LEDC_SLEEP_MODE_INVALID:
        return "Invalid";
    default:
        return "Unknown";
    }
}

static char * clock_str(const ledc_clk_cfg_t clock) {
    switch (clock)
    {
    case LEDC_AUTO_CLK: 
        return "AUTO";
    case LEDC_USE_APB_CLK: //80MHz
        return "APB";
    case LEDC_USE_RC_FAST_CLK: //~8MHz (Low speed only)
        return "RC_FAST";
    case LEDC_USE_REF_TICK: //1MHz
        return "REF_TICK";
    default:
        return "Unknown";
    }
}

static char * event_str(const ledc_cb_event_t event) {
    switch (event)
    {
    case LEDC_FADE_END_EVT:
        return "Fade end";
    default:
        return "Unknown";
    }
}

static soc_module_clk_t get_clock_source_by_register(const ledc_timer_config_t timer) {
    uint32_t tick_sel = LEDC.timer_group[timer.speed_mode].timer[timer.timer_num].conf.tick_sel;
    uint32_t slow_clk_sel = LEDC.conf.slow_clk_sel;

    log_msg(TAG, "High speed clock raw : %d", tick_sel);
    log_msg(TAG, "Low speed clock raw : %d", slow_clk_sel);
    
    // 0 est la valeur par défaut sécurisée (souvent REF_TICK ou INVALID selon le contexte)
    soc_module_clk_t clk = (soc_module_clk_t)0;

    if (timer.speed_mode == LEDC_HIGH_SPEED_MODE) {
        // High Speed : 1 = APB, 0 = REF_TICK, for ESPs
        clk = (tick_sel == 1) ? SOC_MOD_CLK_APB : SOC_MOD_CLK_REF_TICK;
    } else {
        // Low Speed : global clock
        if (slow_clk_sel == 0) {
            clk = SOC_MOD_CLK_APB;
        } else if (slow_clk_sel == 1) {
            clk = SOC_MOD_CLK_RC_FAST;
        } else if (slow_clk_sel == 2) {
            clk = SOC_MOD_CLK_REF_TICK;
        } else {
            clk = SOC_MOD_CLK_APB; // Default fallback.. TODO: other clocks
        }
    }
    return clk;
}

static void print_timer_config(const ledc_timer_config_t config) {
    log_msg(TAG, "Timer index : %d", config.timer_num); //max?
    log_msg(TAG, "Duty resolution : %d", config.duty_resolution); //max?
    log_msg(TAG, "Frequency : %d", config.freq_hz);
    log_msg(TAG, "Speed mode : %s", mode_str(config.speed_mode));
    log_msg(TAG, "Clock : %s", clock_str(config.clk_cfg));
    log_msg(TAG, "Deconfigure : %s", config.deconfigure ? "Yes" : "No");
}

static void print_channel_config(const ledc_channel_config_t config) {
    log_msg(TAG, "Channel : %d", config.channel); //max?
    log_msg(TAG, "GPIO num : %d", config.gpio_num);
    log_msg(TAG, "Speed mode : %s", mode_str(config.speed_mode));
    log_msg(TAG, "Interrupt type (deprecated) : %s", itr_str(config.intr_type));
    log_msg(TAG, "Timer index : %d", config.timer_sel); //max?
    log_msg(TAG, "Duty : %d", config.duty);
    log_msg(TAG, "Hpoint : %d", config.hpoint);
    log_msg(TAG, "Sleep mode : %s", sleep_str(config.sleep_mode));
    log_msg(TAG, "Deconfigure : %s", config.deconfigure ? "Yes" : "No");
    log_msg(TAG, "Output invert : %s", config.flags.output_invert ? "Yes" : "No");
}

static void print_callback_param(const ledc_cb_param_t cb) {
    log_msg(TAG, "Channel : %d", cb.channel);
    log_msg(TAG, "Event : %s", event_str(cb.event));
    log_msg(TAG, "Speed mode : %s", mode_str(cb.speed_mode));
    log_msg(TAG, "Duty : %s", cb.duty);
}
#endif

#if CONFIG_DEBUG_GPIO
static char * drive_cap_str(const gpio_drive_cap_t drive) {
    switch (drive)
    {
    case GPIO_DRIVE_CAP_0:
        return "Weak";
    case GPIO_DRIVE_CAP_1:
        return "Stronger"; 
    case GPIO_DRIVE_CAP_2:
        return "Medium";
    case GPIO_DRIVE_CAP_3:
        return "Strongest";
    case GPIO_DRIVE_CAP_MAX:
        return "MAX";
    default:
        return "Unknown";
    }
}

static void print_gpio_config(const gpio_io_config_t config) {
    //current (mA) to change pin level
    log_msg(TAG, "Drive strength : %s", drive_cap_str(config.drv));

    //multiplexer, owner of pin (uart, spi..)
    log_msg(TAG, "IOMUX function : %u", config.fun_sel);
    //GPIO Matrix : component using pin
    log_msg(TAG, "Outputting index : %u", config.sig_out);

    //Pull signal up to 3.3v when nothing is connected (internal resistances)
    log_msg(TAG, "Pull-up enabled : %s", config.pu ? "Yes" : "No");
    //Pull signal down to 0v when nothing is connected (internal resistances)
    log_msg(TAG, "Pull-down enabled : %s", config.pd ? "Yes" : "No");

    //input mode : reading signal
    log_msg(TAG, "Input enabled : %s", config.ie ? "Yes" : "No");
    //output mode : generating signal
    log_msg(TAG, "Output enabled : %s", config.oe ? "Yes" : "No");

    //Software, or Peripheral (Hardware) for complex protocols (I2C/SPI)
    log_msg(TAG, "Output from peripheral enabled : %s", config.oe_ctrl_by_periph ? "Yes" : "No");

    //signal inversed
    log_msg(TAG, "Output inversed enabled : %s", config.oe_inv ? "Yes" : "No");

    //Modes : Push-pull (normal), Open-drain -> pin tends to gnd 0v, for I2C
    log_msg(TAG, "Open-drain enabled : %s", config.od ? "Yes" : "No");

    //define pin's behaviour when sleeping
    log_msg(TAG, "Pin sleep status enabled : %s", config.slp_sel ? "Yes" : "No");
}
#endif

#if CONFIG_DEBUG_LEDC || CONFIG_DEBUG_GPIO
void print_esp_info_ledc() {

    esp_err_t err;

#if CONFIG_DEBUG_LEDC
    log_msg(TAG, "============= LEDC capabilities =============");

    log_msg(TAG, "LEDC timers        : %d", SOC_LEDC_TIMER_NUM);
    log_msg(TAG, "LEDC channels      : %d", SOC_LEDC_CHANNEL_NUM);
    log_msg(TAG, "Max duty resolution: %d bits", SOC_LEDC_TIMER_BIT_WIDTH);

    //SOC_LEDC_HAS_TIMER_SPECIFIC_MUX;

    #if SOC_LEDC_SUPPORT_HS_MODE
        log_msg(TAG, "High Speed mode    : SUPPORTED");
    #else
        log_msg(TAG, "High Speed mode    : NOT supported (LS only)");
    #endif

    #if SOC_LEDC_SUPPORT_REF_TICK
        log_msg(TAG, "REF_TICK clock     : SUPPORTED (light sleep safe)");
    #else
        log_msg(TAG, "REF_TICK clock     : NOT supported");
    #endif

    #if SOC_LEDC_SUPPORT_APB_CLOCK
        log_msg(TAG, "APB clock (80 MHz) : SUPPORTED");
    #else
        log_msg(TAG, "APB clock (80 MHz) : NOT supported");
    #endif

    uint32_t val;

    int val_int;
    for (int i = 0; i < LEDC_NUM_TEST; i++) {
        print_channel_config(ledc_channel[i]);
        val_int = ledc_get_hpoint(ledc_channel[i].speed_mode, ledc_channel[i].channel);
        log_msg(TAG, "Hpoint channel %d : %d", i, val_int);
        val = ledc_get_duty(ledc_channel[i].speed_mode, ledc_channel[i].channel);
        log_msg(TAG, "Duty channel %d : %d", i, val);
    }

    print_timer_config(ledc_timer_bts);
    print_timer_config(ledc_timer_mg);

    val = ledc_get_freq(ledc_timer_bts.speed_mode, ledc_timer_bts.timer_num);
    log_msg(TAG, "BTS Frequence : %d", val);

    //clock : APB, REF_TICK, RC_FAST
    soc_module_clk_t clock = get_clock_source_by_register(ledc_timer_bts);
    
    //precision : cached, approx, exact, invalid
    //for specific clocks, like RC_FAST 
    esp_clk_tree_src_freq_precision_t precision = ESP_CLK_TREE_SRC_FREQ_PRECISION_EXACT; //exact
    err = esp_clk_tree_src_get_freq_hz(clock, precision, &val);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) getting clock frequency for BTS",
            esp_err_to_name(err));
    }
    log_msg(TAG, "BTS clock frequency : %d", val);

    val = ledc_find_suitable_duty_resolution(val, BTS_FREQ);
    log_msg(TAG, "BTS suitable duty resolution : %d", val);

    val = ledc_get_freq(ledc_timer_mg.speed_mode, ledc_timer_mg.timer_num);
    log_msg(TAG, "MG Frequence : %d", val);

    clock = get_clock_source_by_register(ledc_timer_mg);

    precision = ESP_CLK_TREE_SRC_FREQ_PRECISION_EXACT; //exact
    err = esp_clk_tree_src_get_freq_hz(clock, precision, &val);
    if (err != ESP_OK) {
        log_msg(TAG, "Error (%s) getting clock frequency for MG",
            esp_err_to_name(err));
    }
    log_msg(TAG, "MG clock frequency : %d", val);

    val = ledc_find_suitable_duty_resolution(val, MG_FREQ);
    log_msg(TAG, "MG suitable duty resolution : %d", val);
#endif

#if CONFIG_DEBUG_GPIO
    log_msg(TAG, "============= GPIO capabilities =============");
    log_msg(TAG, "GPIO pin count        : %d", GPIO_PIN_COUNT);

    gpio_io_config_t out_io_config;
    gpio_drive_cap_t drive_cap;
    for (int i = 0; i < GPIO_PIN_COUNT; i++) {
        err = gpio_get_io_config(i, &out_io_config);
        if (err != ESP_OK) {
            log_msg(TAG, "Error (%s) getting GPIO config for pin %d",
                esp_err_to_name(err), i);
        }
        log_msg(TAG, "GPIO pin %d; valid : %d, valid output: %d, valid pad : %d",
            i, GPIO_IS_VALID_GPIO(i), GPIO_IS_VALID_OUTPUT_GPIO(i), GPIO_IS_VALID_DIGITAL_IO_PAD(i));
        ;
        log_msg(TAG, "Reserved : %s", esp_gpio_is_reserved(BIT64(i)) ? "Yes" : "No");
        print_gpio_config(out_io_config);
        log_msg(TAG, "Level : %d", gpio_get_level(i));
        err = gpio_get_drive_capability(i, &drive_cap);
        if (err != ESP_OK) {
            log_msg(TAG, "Error (%s) getting GPIO drive capability for pin %d",
                esp_err_to_name(err), i);
        }
        log_msg(TAG, "Strength : %s", drive_cap_str(drive_cap));
    }
#endif

    log_msg(TAG, "=============================================");
}
#endif

void dump_gpio_stats() {
#if CONFIG_DEBUG_GPIO
    gpio_dump_io_configuration(stdout, SOC_GPIO_VALID_GPIO_MASK);
#endif
}