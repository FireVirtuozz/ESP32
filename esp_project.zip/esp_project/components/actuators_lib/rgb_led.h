#ifndef RGB_LED_H_
#define RGB_LED_H_

#include "ledLib.h"

// KY009 : RGB LED without resistances (put it by yourself) powered by PWM
// KY016 : RGB LED with resitances powered by PWM

#define KY009_RED_GPIO          18  // À adapter selon ton câblage
#define KY009_GREEN_GPIO        19   // À adapter selon ton câblage
#define KY009_BLUE_GPIO         17  // À adapter selon ton câblage
#define KY009_RESOLUTION        LEDC_TIMER_13_BIT
#define KY009_FREQ              5000 // 5 kHz (parfait pour les LEDs, aucun scintillement)
#define KY009_MIN_DUTY          0
#define KY009_MAX_DUTY          GET_MAX_DUTY(KY009_RESOLUTION) // 100% de luminosité (pas divisé par 2 !)
#define KY009_SPEED_MODE        LEDC_LOW_SPEED_MODE
#define KY009_LEDC_TIMER        LEDC_TIMER_3  // Nouveau timer (car fréquence différente du buzzer)
#define KY009_RED_CHANNEL       LEDC_CHANNEL_5
#define KY009_GREEN_CHANNEL     LEDC_CHANNEL_6
#define KY009_BLUE_CHANNEL     LEDC_CHANNEL_7

#if CONFIG_USE_KY009
    #define KY009_CHANNELS 3
#else
    #define KY009_CHANNELS 0
#endif

#endif